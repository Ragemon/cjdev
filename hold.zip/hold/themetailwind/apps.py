from django.apps import AppConfig


class ThemetailwindConfig(AppConfig):
    name = 'themetailwind'
